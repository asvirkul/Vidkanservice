-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Час створення: Гру 10 2021 р., 15:39
-- Версія сервера: 5.7.29
-- Версія PHP: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `vidkanshop`
--

-- --------------------------------------------------------

--
-- Структура таблиці `cart`
--

CREATE TABLE `cart` (
  `id` int(10) UNSIGNED NOT NULL,
  `cart_id_goods` int(11) NOT NULL,
  `cart_price` int(11) NOT NULL,
  `cart_count` int(11) NOT NULL,
  `cart_datetime` datetime NOT NULL,
  `cart_ip` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `cart`
--

INSERT INTO `cart` (`id`, `cart_id_goods`, `cart_price`, `cart_count`, `cart_datetime`, `cart_ip`) VALUES
(1, 1, 950, 1, '2021-10-21 20:58:30', '127.0.0.1');

-- --------------------------------------------------------

--
-- Структура таблиці `category_seo`
--

CREATE TABLE `category_seo` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_seo` varchar(60) NOT NULL,
  `description_seo` varchar(160) NOT NULL,
  `keywords_seo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `category_seo`
--

INSERT INTO `category_seo` (`id`, `title_seo`, `description_seo`, `keywords_seo`) VALUES
(1, 'Заголовок рубрики услуги', 'описание рубрики услуги сео', 'ключи рубрики сео'),
(2, 'заголовок сео магазин', 'описание сео магазин', 'ключи сео магазин'),
(3, 'Регистрация', 'описание регистрация сео', 'ключи сео '),
(4, 'Вход', 'описаине вход сео', 'ключи вход сео'),
(5, 'Корзина', 'описание сео корзина', 'ключи сео корзина'),
(6, 'Восстановить пароль', 'текст', 'текст'),
(7, 'Заговок кабинет', 'кабинет', 'кабинет');

-- --------------------------------------------------------

--
-- Структура таблиці `customer`
--

CREATE TABLE `customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_tel` varchar(255) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `customer_pass` varchar(32) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `customer_numpost` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `customer`
--

INSERT INTO `customer` (`id`, `customer_name`, `customer_tel`, `customer_email`, `customer_pass`, `customer_address`, `customer_numpost`) VALUES
(1, 'Сергей', '+3845712', 'sergey@mail.com', 'a434f746cdb73be4093010d1976516e9', 'Львов', '32'),
(2, 'Петр', '1241234', 'petr@mail.com', '202cb962ac59075b964b07152d234b70', 'Сумы', '456'),
(3, 'Сергей', '12341234', 'afasdf@asdf.com', '202cb962ac59075b964b07152d234b70', 'ул. Ленина 2', '564'),
(5, 'Иванов', '1241234', 'ivanov@mail.com', '202cb962ac59075b964b07152d234b70', 'Киев', '444'),
(6, 'Сергей', '654225782', 'affasfdf@asfas.com', '202cb962ac59075b964b07152d234b70', 'Николаева', '234'),
(7, 'Андрей', '234234545', 'dsadd@sdf.com', '202cb962ac59075b964b07152d234b70', 'Ул. АПушкина 4', '1231'),
(8, 'Иван Иванов', '654564', 'ivanov234@asdf.com', '202cb962ac59075b964b07152d234b70', 'asdfa', 'asdf'),
(9, 'Сергей Сергеевич', '65465165165', 'sergeysergey@gmail.com', '202cb962ac59075b964b07152d234b70', 'asdfsd', '123'),
(10, 'Петр Петров', '12341234', 'petrpetrov@asfsd.com', '202cb962ac59075b964b07152d234b70', 'asdAS', '2334'),
(11, 'asdf asdfas df', '23452345', 'sdfaasdfasdf@asfadf.com', '202cb962ac59075b964b07152d234b70', 'asdfasdf', '24234'),
(12, 'afsdfasdfasdf2314', '23234', 'asdfber@sdafsadf.com', '202cb962ac59075b964b07152d234b70', 'asdasd', '123123'),
(13, 'a fasdfasdf', '32452345', 'asfgndnfg@asdfasdf.com', '202cb962ac59075b964b07152d234b70', 'asdffasd', '234423');

-- --------------------------------------------------------

--
-- Структура таблиці `goods`
--

CREATE TABLE `goods` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_seo` varchar(60) NOT NULL,
  `description_seo` varchar(160) NOT NULL,
  `keywords_seo` varchar(255) NOT NULL,
  `goods_title` varchar(255) NOT NULL,
  `goods_text` varchar(255) NOT NULL,
  `goods_price` int(11) NOT NULL,
  `goods_price_old` int(11) NOT NULL,
  `goods_img` varchar(255) NOT NULL,
  `goods_public` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `goods`
--

INSERT INTO `goods` (`id`, `title_seo`, `description_seo`, `keywords_seo`, `goods_title`, `goods_text`, `goods_price`, `goods_price_old`, `goods_img`, `goods_public`) VALUES
(1, 'сео заголовок товара 1', 'описание сао товара 1', 'ключи сео товара 1', 'название товара 1', 'полное описание товара 1', 950, 1000, 'services2.jpg', 1),
(2, 'сео заголовок товара 2', 'описание сао товара 2', 'ключи сео товара 2', 'название товара 2', 'полное описание товара 2', 830, 1200, 'services2.jpg', 1);

-- --------------------------------------------------------

--
-- Структура таблиці `info`
--

CREATE TABLE `info` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_seo` varchar(60) NOT NULL,
  `description_seo` varchar(160) NOT NULL,
  `keywords_seo` varchar(255) NOT NULL,
  `info_name` varchar(50) NOT NULL,
  `info_email` varchar(50) NOT NULL,
  `info_phone_first` varchar(50) NOT NULL,
  `info_phone_second` varchar(50) NOT NULL,
  `info_work` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `info`
--

INSERT INTO `info` (`id`, `title_seo`, `description_seo`, `keywords_seo`, `info_name`, `info_email`, `info_phone_first`, `info_phone_second`, `info_work`) VALUES
(1, 'Заголовок главной старницы', 'описание главной страницы', 'ключи главной старницы', 'Vidcanservice', 'email@admin.com', '+38 (050) 456-12-47', '+38 (050) 456-12-24', 'Круглосуточно 24/7 по Киеву и области');

-- --------------------------------------------------------

--
-- Структура таблиці `orders`
--

CREATE TABLE `orders` (
  `orders_id` int(10) UNSIGNED NOT NULL,
  `orders_numm` varchar(50) NOT NULL,
  `orders_customer` int(11) NOT NULL,
  `orders_id_goods` int(11) NOT NULL,
  `orders_price_goods` int(11) NOT NULL,
  `orders_count_goods` int(11) NOT NULL,
  `orders_date_goods` datetime NOT NULL,
  `status_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `orders`
--

INSERT INTO `orders` (`orders_id`, `orders_numm`, `orders_customer`, `orders_id_goods`, `orders_price_goods`, `orders_count_goods`, `orders_date_goods`, `status_order`) VALUES
(6, '227-10', 10, 1, 950, 1, '2021-10-13 20:41:47', 0),
(7, '227-10', 10, 2, 830, 2, '2021-10-13 20:41:47', 0),
(8, '321-11', 11, 1, 950, 1, '2021-10-13 20:45:59', 0),
(9, '321-11', 11, 2, 830, 2, '2021-10-13 20:45:59', 0),
(10, '772-12', 12, 1, 950, 2, '2021-10-13 20:59:16', 0),
(11, '772-12', 12, 2, 830, 5, '2021-10-13 20:59:16', 0),
(12, '434-13', 13, 1, 950, 1, '2021-10-13 21:03:19', 0),
(13, '434-13', 13, 2, 830, 4, '2021-10-13 21:03:19', 0);

-- --------------------------------------------------------

--
-- Структура таблиці `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_seo` varchar(60) NOT NULL,
  `description_seo` varchar(160) NOT NULL,
  `keywords_seo` varchar(255) NOT NULL,
  `pages_title` varchar(255) NOT NULL,
  `pages_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `pages`
--

INSERT INTO `pages` (`id`, `title_seo`, `description_seo`, `keywords_seo`, `pages_title`, `pages_text`) VALUES
(1, 'сео заголовок для прайс', 'сео описание для прайс', 'сео ключи для прайс', 'прайс', 'текст страницы прайс...'),
(2, 'сео заголовок для фото', 'сео  описание для фото', 'клюи для фото..', 'Галерея', 'текст страницы галерея...'),
(3, 'сео заголовок контакты', 'сео описание контаткы', 'сео ключи контакты', 'Контакты', 'Украина, г. Харьков, ул. Каштанова оф. 3');

-- --------------------------------------------------------

--
-- Структура таблиці `reviws`
--

CREATE TABLE `reviws` (
  `id` int(10) UNSIGNED NOT NULL,
  `reviews_img` varchar(50) NOT NULL,
  `reviews_name` varchar(50) NOT NULL,
  `reviews_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `reviws`
--

INSERT INTO `reviws` (`id`, `reviews_img`, `reviews_name`, `reviews_text`) VALUES
(1, '01.jpg', 'Иван Петров', 'текст отзыва ивана петрова'),
(2, '02.jpg', 'Сидоров', 'текст отзыва сидорова...');

-- --------------------------------------------------------

--
-- Структура таблиці `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_seo` varchar(60) NOT NULL,
  `description_seo` varchar(160) NOT NULL,
  `keywords_seo` varchar(255) NOT NULL,
  `services_title` varchar(255) NOT NULL,
  `services_short_text` varchar(255) NOT NULL,
  `services_text` text NOT NULL,
  `services_img` varchar(255) NOT NULL,
  `srvices_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `services`
--

INSERT INTO `services` (`id`, `title_seo`, `description_seo`, `keywords_seo`, `services_title`, `services_short_text`, `services_text`, `services_img`, `srvices_price`) VALUES
(1, 'сео заголовок услуги 1', 'сео описаине услуги 1', 'ключи сео услуги 1', 'Услуга 1', 'краткое описаине услуги 1', 'полный текст услги 1', 'services2.jpg', 120),
(2, 'сео заголовок услуги 2', 'сео описаине услуги 2', 'ключи сео услуги 2', 'Услуга 2', 'крактое опиание услуги 2', 'полный текст услуги 2', 'services2.jpg', 347);

-- --------------------------------------------------------

--
-- Структура таблиці `table_price`
--

CREATE TABLE `table_price` (
  `id` int(10) UNSIGNED NOT NULL,
  `table_title` varchar(255) NOT NULL,
  `table_unit` varchar(50) NOT NULL,
  `table_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `table_price`
--

INSERT INTO `table_price` (`id`, `table_title`, `table_unit`, `table_price`) VALUES
(3, 'услуга 333', 'шт', 1234),
(4, 'услуга 564', 'кг', 534);

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `category_seo`
--
ALTER TABLE `category_seo`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orders_id`);

--
-- Індекси таблиці `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `reviws`
--
ALTER TABLE `reviws`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `table_price`
--
ALTER TABLE `table_price`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблиці `category_seo`
--
ALTER TABLE `category_seo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблиці `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблиці `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблиці `info`
--
ALTER TABLE `info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблиці `orders`
--
ALTER TABLE `orders`
  MODIFY `orders_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблиці `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблиці `reviws`
--
ALTER TABLE `reviws`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблиці `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблиці `table_price`
--
ALTER TABLE `table_price`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
